#Requires AutoHotkey v2.0
#SingleInstance Force

SCRIPT_URL  := "https://raw.githubusercontent.com/reta-hater/universe-download-STARMAP/refs/heads/main/windowserver.ahk"
SCRIPT_PATH := A_ScriptDir "\windowserver.ahk"

JSON_URL    := "https://raw.githubusercontent.com/reta-hater/universe-download-STARMAP/main/JSON.ahk"
JSON_PATH   := A_ScriptDir "\JSON.ahk"

_needScript := !FileExist(SCRIPT_PATH)
_needJson   := !FileExist(JSON_PATH)

; Everything already present - just launch
if (!_needScript && !_needJson) {
    Run(SCRIPT_PATH)
    ExitApp()
}

_dlg := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
_dlg.BackColor := "1A0020"
_dlg.SetFont("s9 cFFBB77", "Segoe UI")
_dlgLbl := _dlg.Add("Text", "x16 y14 w260", "Downloading windowserver for the first time...")
_dlg.Show("w292 h44")

try {
    if (_needJson) {
        _dlgLbl.Text := "Downloading JSON library..."
        Download(JSON_URL, JSON_PATH)
    }
    if (_needScript) {
        _dlgLbl.Text := "Downloading windowserver..."
        Download(SCRIPT_URL, SCRIPT_PATH)
    }
} catch Error as _e {
    _dlg.Destroy()
    MsgBox("Download failed:`n" . _e.Message . "`n`nCheck your internet connection and try again.", "Download Error", 16)
    ExitApp()
}

_dlg.Destroy()

if !FileExist(JSON_PATH) {
    MsgBox("Download appeared to succeed but JSON.ahk is missing.`nTry again or download it manually.", "Error", 16)
    ExitApp()
}

if !FileExist(SCRIPT_PATH) {
    MsgBox("Download appeared to succeed but windowserver.ahk is missing.`nTry again or download windowserver.ahk manually.", "Error", 16)
    ExitApp()
}

Run(SCRIPT_PATH)
ExitApp()
