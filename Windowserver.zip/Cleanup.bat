@echo off
echo Cleaning up Universe Planet Search temp files...
echo.

set TEMP_FILES=^
    "%TEMP%\ups_universe.json" ^
    "%TEMP%\ups_planet.ico" ^
    "%TEMP%\ups_version.txt" ^
    "%TEMP%\ups_query.ps1" ^
    "%TEMP%\ups_results.txt" ^
    "%TEMP%\ups_new_script.ahk" ^
    "%TEMP%\ups_updater.bat" ^
    "%TEMP%\ups_ver_tmp.txt"

for %%F in (
    "%TEMP%\ups_universe.json"
    "%TEMP%\ups_planet.ico"
    "%TEMP%\ups_version.txt"
    "%TEMP%\ups_query.ps1"
    "%TEMP%\ups_results.txt"
    "%TEMP%\ups_new_script.ahk"
    "%TEMP%\ups_updater.bat"
    "%TEMP%\ups_ver_tmp.txt"
) do (
    if exist %%F (
        del /f /q %%F
        echo Deleted: %%F
    ) else (
        echo Not found: %%F
    )
)

echo.
echo Done.
pause
